/* ARCAWORD 3.0 — conta e venda. Nenhum segredo de pagamento é armazenado aqui. */
(() => {
 'use strict';
 const cfg=window.CPM_CONFIG||{};
 const enabled=()=>!window.CPM_DEMO_ONLY && /^https:\/\/[^/]+\.supabase\.co\/?$/.test(cfg.supabaseUrl||'') && !!cfg.supabaseAnonKey && !cfg.supabaseAnonKey.includes('COLE_');
 const $=id=>document.getElementById(id);
 const AUTH_KEY='cpm-shop-auth-v3';
 let session=null,emailPending='',premium=false,checking=false;
 try{session=JSON.parse(localStorage.getItem(AUTH_KEY)||'null')}catch{}
 const notify=()=>window.dispatchEvent(new Event('cpm-shop-change'));
 const putSession=s=>{session=s?{access_token:s.access_token,refresh_token:s.refresh_token,expires_at:Date.now()+Math.max(0,Number(s.expires_in||3600)-60)*1000,email:s.user?.email||s.email||session?.email||''}:null;
  try{if(session)localStorage.setItem(AUTH_KEY,JSON.stringify(session));else localStorage.removeItem(AUTH_KEY)}catch{};notify()};
 function notice(text,type='info'){const el=$('shopNotice');if(!el)return;el.textContent=text;el.dataset.type=type}
 const apiBase=()=>cfg.supabaseUrl.replace(/\/$/,'')+'/auth/v1';
 async function authRequest(path,payload){
  const r=await fetch(apiBase()+path,{method:'POST',headers:{'Content-Type':'application/json',apikey:cfg.supabaseAnonKey},body:JSON.stringify(payload)});
  const data=await r.json().catch(()=>({}));if(!r.ok)throw Error(data.msg||data.error_description||data.message||'Falha na autenticação');return data;
 }
 async function token(){
  if(!session)return null;
  if(Date.now()<session.expires_at-1000)return session.access_token;
  try{const next=await authRequest('/token?grant_type=refresh_token',{refresh_token:session.refresh_token});putSession(next);return session.access_token}
  catch(e){putSession(null);premium=false;render();return null}
 }
 async function call(path,body=null){
  const bearer=await token();if(!bearer)throw Error('Entre com seu e-mail primeiro.');
  const resp=await fetch('/.netlify/functions/'+path,{method:body===null?'GET':'POST',headers:{authorization:'Bearer '+bearer,...(body!==null?{'Content-Type':'application/json'}:{})},body:body===null?undefined:JSON.stringify(body),cache:'no-store'});
  const data=await resp.json().catch(()=>({}));if(!resp.ok)throw Error(data.error||'Falha na comunicação.');return data;
 }
 function render(){
  if(!$('shopScreen'))return;
  $('authForm').hidden=!!session||!!emailPending||!enabled();$('codeForm').hidden=!emailPending||!!session||!enabled();
  $('loggedInPanel').hidden=!session||!enabled();$('shopSetup').hidden=enabled();
  $('premiumState').textContent=premium?'✅ Premium ativo — 650 fases nos dois jogos liberadas':'🔒 16 fases grátis · desbloqueie 634 fases e mais 11 temas por R$ 3,99';
  $('accountEmail').textContent=session?.email||'';
  $('buyBtn').hidden=premium;$('buyBtn').disabled=checking;
  $('logoutBtn').hidden=!session;
  $('premiumCardLabel').textContent=premium?'👑 Seu Premium está ativo':'👑 Premium — libere 634 fases nos dois jogos';
  $('premiumCardDetail').textContent=premium?'Aproveite todas as categorias e desafios!':'Pagamento único de R$ 3,99 · Sem assinatura';
  if(session&&premium)$('shopHeadline').textContent='Seu acesso está liberado!';else $('shopHeadline').textContent='Desbloqueie o Premium';
  notify();
 }
 async function refresh(silent=false){if(!enabled()){render();return false}if(!session){premium=false;render();return false}
  try{checking=true;render();const s=await call('status');premium=!!s.premium;render();if(!silent)notice(premium?'Acesso Premium confirmado!':'Aguardando pagamento aprovado.','ok');return premium}
  catch(e){if(!silent)notice(e.message,'error');return false}finally{checking=false;render()}
 }
 async function sendCode(){if(!enabled()){notice('Finalize a configuração antes de vender.','error');return}
  const email=($('shopEmail').value||'').trim().toLowerCase();if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){notice('Digite um e-mail válido.','error');return}
  $('sendCodeBtn').disabled=true;
  try{await authRequest('/otp',{email,create_user:true});emailPending=email;render();notice('Enviamos um código por e-mail. Confira sua caixa de entrada e spam.','ok')}
  catch(e){notice(e.message,'error')}finally{$('sendCodeBtn').disabled=false}
 }
 async function verifyCode(){const code=($('shopCode').value||'').trim();if(!/^\d{6,8}$/.test(code)){notice('Digite o código numérico recebido.','error');return}
  $('verifyCodeBtn').disabled=true;
  try{const result=await authRequest('/verify',{email:emailPending,token:code,type:'email'});putSession(result);emailPending='';premium=false;render();await refresh();notice('Conta acessada com sucesso.','ok')}
  catch(e){notice(e.message,'error')}finally{$('verifyCodeBtn').disabled=false}
 }
 async function buy(){if(!session){notice('Faça login antes de comprar.','error');return}
  $('buyBtn').disabled=true;notice('Abrindo o checkout seguro do Mercado Pago…');
  try{const result=await call('create-checkout',{});if(result.premium){premium=true;render();notice('Sua conta já tem acesso Premium.','ok');return}
   const checkout=new URL(result.url);if(!checkout.protocol.startsWith('https')||!checkout.hostname.endsWith('mercadopago.com.br')&&!checkout.hostname.endsWith('mercadopago.com'))throw Error('Endereço de pagamento inesperado.');
   location.href=result.url;
  }catch(e){notice(e.message,'error');$('buyBtn').disabled=false}
 }
 async function syncAfterPayment(){const url=new URL(location.href),flag=url.searchParams.get('pagamento');if(!flag)return;
  window.CPMShop.open();
  if(flag==='falhou'){notice('O pagamento não foi concluído. Você pode tentar novamente.','error')}
  else if(flag==='pendente'){notice('Pagamento pendente. O Premium será liberado após aprovação.')}
  else{notice('Pagamento recebido para conferência. Aguardando confirmação oficial do Mercado Pago.');
   const id=url.searchParams.get('payment_id')||url.searchParams.get('collection_id');
   if(id&&session){try{const p=await call('sync-payment',{payment_id:id});if(p.approved)await refresh();else notice('O pagamento ainda está em análise: '+p.status)}catch(e){notice(e.message,'error')}}
  }
  url.searchParams.delete('pagamento');url.searchParams.delete('payment_id');url.searchParams.delete('collection_id');url.searchParams.delete('collection_status');url.searchParams.delete('status');url.searchParams.delete('preference_id');history.replaceState({},'',url.pathname+url.search+url.hash);
 }
 async function getPuzzle(cat,n){const data=await call('puzzle?categoria='+encodeURIComponent(cat)+'&fase='+n);return data.puzzle}
 async function getCrossword(cat,n){const data=await call('crossword?categoria='+encodeURIComponent(cat)+'&fase='+n);return data.puzzle}
 function open(){window.CPMOpenShop?.();render();if(session)refresh(true)}
 function wire(){
  $('authForm')?.addEventListener('submit',e=>{e.preventDefault();sendCode()});
  $('codeForm')?.addEventListener('submit',e=>{e.preventDefault();verifyCode()});
  $('buyBtn')?.addEventListener('click',buy);$('refreshAccessBtn')?.addEventListener('click',()=>refresh());
  $('logoutBtn')?.addEventListener('click',()=>{putSession(null);premium=false;emailPending='';render();notice('Você saiu da sua conta.');});
  $('shopBtn')?.addEventListener('click',open);$('premiumCard')?.addEventListener('click',open);
  $('shopBack')?.addEventListener('click',()=>window.CPMShowHome?.());
  render();if(session)refresh(true).then(syncAfterPayment);else syncAfterPayment();
 }
 window.CPMShop={isPremium:()=>premium,open,refresh,getPuzzle,getCrossword,enabled,getAccessToken:token,hasSession:()=>!!session};
 document.addEventListener('DOMContentLoaded',wire);
})();
