(() => {
  'use strict';
  // Progresso local, nunca dados de autenticação, compra ou liberação Premium.
  const prefixes=['cpm-v1:','cpm-cross-v1:'];
  const isProgressKey=k=>prefixes.some(prefix=>k.startsWith(prefix));
  const status=document.getElementById('backupStatus');
  const setStatus=(msg)=>{if(status)status.textContent=msg;};
  const exportBtn=document.getElementById('backupExportBtn');
  const importBtn=document.getElementById('backupImportBtn');
  const fileInput=document.getElementById('backupFile');
  if(!exportBtn||!importBtn||!fileInput)return;
  function getSnapshot(){
    const items={};
    for(let i=0;i<localStorage.length;i++){
      const k=localStorage.key(i);
      if(isProgressKey(k))items[k]=localStorage.getItem(k);
    }
    return {app:'ARCAWORD',type:'local-progress-backup',format:1,createdAt:new Date().toISOString(),items};
  }
  exportBtn.addEventListener('click',async()=>{
    let url;
    try{
      const data=JSON.stringify(getSnapshot(),null,2);
      const file=new File([data],'arcaword-progresso.json',{type:'application/json'});
      // Share to Files via native iOS dialog when supported.
      if(navigator.share && navigator.canShare && navigator.canShare({files:[file]})){
        try{await navigator.share({files:[file],title:'Cópia do progresso ARCAWORD'});setStatus('Cópia enviada. Guarde o arquivo no app Arquivos.');return;}
        catch(e){if(e.name==='AbortError'){setStatus('Compartilhamento cancelado.');return;}}
      }
      url=URL.createObjectURL(file);
      const a=document.createElement('a');a.href=url;a.download='arcaword-progresso.json';
      document.body.append(a);a.click();a.remove();
      setStatus('Arquivo de progresso gerado. Guarde-o antes de remover o ícone antigo.');
    }catch(e){setStatus('Não foi possível salvar o progresso neste navegador.');}
    finally{if(url)setTimeout(()=>URL.revokeObjectURL(url),4000);}
  });
  importBtn.addEventListener('click',()=>fileInput.click());
  fileInput.addEventListener('change',async()=>{
    const file=fileInput.files?.[0];if(!file)return;
    try{
      if(file.size>1000000)throw new Error('Arquivo muito grande.');
      const backup=JSON.parse(await file.text());
      if(backup?.app!=='ARCAWORD'||backup?.type!=='local-progress-backup'||backup?.format!==1||!backup.items||typeof backup.items!=='object'||Array.isArray(backup.items))throw new Error('Este não é um arquivo de progresso do ARCAWORD.');
      let count=0;
      for(const [k,v] of Object.entries(backup.items)){
        if(!isProgressKey(k)||typeof v!=='string'||v.length>30000)continue;
        JSON.parse(v); // validate previous JSON structure
        const existing=localStorage.getItem(k);
        // Never mark a completed phase as incomplete when importing an older backup.
        if(k.includes(':done:') && existing==='true')continue;
        if(existing===null||k.includes(':done:')&&v==='true'){
          localStorage.setItem(k,v);count++;
        }
      }
      setStatus(`${count} registro(s) restaurado(s). Atualizando a tela…`);
      setTimeout(()=>location.reload(),800);
    }catch(e){setStatus(`Não foi possível restaurar: ${e.message}`);}
    finally{fileInput.value='';}
  });
})();
