window.CPM_DEMO_ONLY = true;
window.CPM_CONFIG = {supabaseUrl:"",supabaseAnonKey:""};
