(() => {
 'use strict';
 const TOTAL_LEVELS=CATEGORIES.reduce((t,c)=>t+c.levels,0);
 const $ = id => document.getElementById(id);
 const screens = {home:$('homeScreen'),levels:$('levelsScreen'),game:$('gameScreen'),settings:$('settingsScreen'),shop:$('shopScreen'),crossCategories:$('crossCategoriesScreen'),crossLevels:$('crossLevelsScreen'),crossGame:$('crossGameScreen')};
 let currentScreen='home',category=CATEGORIES[0],level=1,puzzle=null,found=new Map(),active=null,pending=null,hints=3,elapsed=0,timer=null,timerBase=0,hintTimer=null,modalOpen=false;
 const freeTheme = id=>window.CPM_FREE_THEME_IDS.includes(id);
 const freeLevel=(id,n)=>freeTheme(id)&&n>=1&&n<=window.CPM_FREE_LEVELS;
 let soundOn=load('pref:sound',true),motionOn=load('pref:motion',true),audioContext=null,settingsReturn='home';

 function load(key,fallback=null){try{const x=localStorage.getItem('cpm-v1:'+key);return x===null?fallback:JSON.parse(x)}catch{return fallback}}
 function save(key,value){try{localStorage.setItem('cpm-v1:'+key,JSON.stringify(value))}catch{}}
 const key=(cat=category,n=level)=>cat.id+'-'+n;
 const isComplete=(cat,n)=>load('done:'+key(cat,n),false)===true;
 function completedCount(cat){let ct=0;const max=cat.levels;for(let n=1;n<=max;n++)if(isComplete(cat,n))ct++;return ct}
 function unlockedLevel(cat){let n=1;while(n<cat.levels && isComplete(cat,n))n++;return n}
 function totalComplete(){return CATEGORIES.reduce((sum,cat)=>sum+completedCount(cat),0)}
 function formatTime(s){return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
 function updateTop(){const n=totalComplete();$('topDone').textContent=n;$('totalDone').textContent=n;$('totalPct').textContent=Math.round(n/TOTAL_LEVELS*100)+'%'}
 function pauseClock(){if(timer){clearInterval(timer);timer=null;elapsed=Math.max(elapsed,Math.floor((Date.now()-timerBase)/1000));save('time:'+key(),elapsed)}}
 function startClock(){if(timer || !puzzle || found.size===puzzle.words.length || currentScreen!=='game')return;timerBase=Date.now()-elapsed*1000;timer=setInterval(()=>{elapsed=Math.floor((Date.now()-timerBase)/1000);$('clock').textContent=formatTime(elapsed);if(elapsed%4===0)save('time:'+key(),elapsed)},500)}
 function showScreen(name){window.CPMCrossword?.onScreenChange?.(name);pauseClock();for(const [k,s] of Object.entries(screens))s.hidden=k!==name;currentScreen=name;$('backBtn').hidden=name==='home';$('winModal').hidden=true;modalOpen=false;window.scrollTo({top:0,behavior:'instant'});if(name==='game')startClock()}
 function showHome(){updateTop();renderCategories();renderContinue();showScreen('home')}
 function renderContinue(){const last=load('last',null);const btn=$('continueBtn');if(!last){btn.hidden=true;return}const cat=CATEGORIES.find(c=>c.id===last.cat);if(!cat){btn.hidden=true;return}const unlocked=unlockedLevel(cat);const n=(isComplete(cat,last.level)&&unlocked>last.level)?unlocked:Math.min(last.level,unlocked);if(!freeLevel(cat.id,n)&&!window.CPMShop.isPremium()){btn.hidden=true;return}btn.hidden=false;$('continueInfo').textContent=`${cat.emoji} ${cat.title} • Fase ${n}`;btn.onclick=()=>{category=cat;openLevel(n)}}
 function renderCategories(){const root=$('homeCategories');root.innerHTML='';for(const cat of CATEGORIES.filter(c=>window.CPMShop.isPremium()||freeTheme(c.id))){const btn=document.createElement('button');btn.type='button';btn.className='category';const locked=!freeTheme(cat.id)&&!window.CPMShop.isPremium();btn.classList.toggle('category-paylocked',locked);btn.innerHTML=`<span class="category-emoji">${cat.emoji}</span><strong>${cat.title}${locked?' 👑':''}</strong><small>${freeTheme(cat.id)?(window.CPMShop.isPremium()?'Acesso total • ':'2 fases grátis • '):'Premium liberado • '}${completedCount(cat)}/${cat.levels} fases concluídas</small><span class="category-arrow">›</span>`;btn.addEventListener('click',()=>locked?window.CPMShop.open():showLevels(cat));root.appendChild(btn)}}
 function showLevels(cat=category){
  if(!freeTheme(cat.id)&&!window.CPMShop.isPremium()){window.CPMShop.open();return}
  category=cat;$('categoryEmoji').textContent=cat.emoji;$('categoryTitle').textContent=cat.title;
  $('categorySubtitle').textContent=`${completedCount(cat)} de ${cat.levels} fases concluídas`;
  const root=$('levelGrid');root.innerHTML='';const unlock=unlockedLevel(cat);
  for(let i=1;i<=cat.levels;i++){
   const done=isComplete(cat,i),paylocked=!freeLevel(cat.id,i)&&!window.CPMShop.isPremium();
   const progresslocked=i>unlock&&!done&&!paylocked,btn=document.createElement('button');
   btn.className='level'+(done?' completed':paylocked?' premium-locked':progresslocked?' locked':'');btn.type='button';
   btn.disabled=progresslocked||done;
   btn.setAttribute('aria-label',`Fase ${i}${done?', concluída':paylocked?', Premium':progresslocked?', bloqueada':''}`);
   btn.innerHTML=done?`✓<span>Fase ${i}</span>`:paylocked?`👑<span>Fase ${i}</span>`:progresslocked?`🔒<span>Fase ${i}</span>`:`${i}<span>JOGAR</span>`;
   btn.addEventListener('click',()=>paylocked&&!done?window.CPMShop.open():openLevel(i));root.appendChild(btn)
  }
  showScreen('levels')
 }
 let puzzleRequestSerial=0;
 async function openLevel(n){
  if(isComplete(category,n)){showLevels();return}
  if(!freeLevel(category.id,n)&&!window.CPMShop.isPremium()){window.CPMShop.open();return}
  pauseClock();const serial=++puzzleRequestSerial;
  const requestedCategory=category;
  let nextPuzzle;
  if(freeLevel(requestedCategory.id,n)){nextPuzzle=FREE_PUZZLES[requestedCategory.id+'-'+n]}
  else{
   try{nextPuzzle=await window.CPMShop.getPuzzle(requestedCategory.id,n)}
   catch(e){if(serial!==puzzleRequestSerial)return;alert('Não foi possível abrir a fase Premium. Verifique sua internet e seu acesso.\n'+e.message);window.CPMShop.open();return}
  }
  if(serial!==puzzleRequestSerial)return;
  if(!nextPuzzle){alert('Esta fase não está disponível.');return}
  level=n;puzzle=nextPuzzle;save('last',{cat:category.id,level:n});
  found=new Map(load('found:'+key(),[])||[]);
  for(const [word,path] of found){if(!puzzle.words.includes(word)||!Array.isArray(path)||!path.every(i=>Number.isInteger(i)&&i>=0&&i<puzzle.grid.length)||(asWord(path)!==word&&asWord(path)!==word.split('').reverse().join('')))found.delete(word)}
  pending=null;active=null;hints=3;elapsed=load('time:'+key(),0)||0;if(hintTimer)clearTimeout(hintTimer);
  $('gameCategory').textContent=category.title.toUpperCase();$('gameLevel').textContent='Fase '+n;$('difficulty').textContent=puzzle.levelName;$('clock').textContent=formatTime(elapsed);$('hintCount').textContent='(3)';$('hintBtn').disabled=false;$('restartBtn').disabled=false;$('gameStatus').textContent='Arraste o dedo pelas letras ou toque na primeira e na última.';
  renderBoard();renderWords();refreshProgress();showScreen('game');if(found.size===puzzle.words.length)$('gameStatus').textContent='Esta fase já foi concluída.'
 }
 function renderBoard(){const root=$('board');root.innerHTML='';root.style.setProperty('--size',puzzle.size);puzzle.grid.forEach((letter,index)=>{const cell=document.createElement('div');cell.className='cell';cell.dataset.i=String(index);cell.textContent=letter;root.appendChild(cell)});refreshBoard()}
 function renderWords(){const root=$('wordList');root.innerHTML='';for(const word of puzzle.words){const div=document.createElement('div');div.className='word';div.dataset.word=word;div.textContent=word;root.appendChild(div)}refreshWords()}
 function refreshWords(){for(const cell of $('wordList').children)cell.classList.toggle('found',found.has(cell.dataset.word))}
 function refreshBoard(selection=[]){const completed=new Set([...found.values()].flat());const chosen=new Set(selection);for(const cell of $('board').children){const i=Number(cell.dataset.i);cell.classList.toggle('found',completed.has(i));cell.classList.toggle('selected',chosen.has(i))}}
 function refreshProgress(){$('foundCounter').textContent=found.size+'/'+puzzle.words.length;$('wordCount').textContent=puzzle.words.length+' palavras';$('progressFill').style.width=(100*found.size/puzzle.words.length)+'%';refreshWords();refreshBoard()}
 function line(a,b){const n=puzzle.size;const r1=Math.floor(a/n),c1=a%n,r2=Math.floor(b/n),c2=b%n,dr=r2-r1,dc=c2-c1;const length=Math.max(Math.abs(dr),Math.abs(dc));if(length===0)return [a];if(dr!==0&&dc!==0&&Math.abs(dr)!==Math.abs(dc))return [];const sr=Math.sign(dr),sc=Math.sign(dc);return Array.from({length:length+1},(_,i)=>(r1+sr*i)*n+c1+sc*i)}
 function asWord(path){return path.map(i=>puzzle.grid[i]).join('')}
 function playTone(win=false){if(!soundOn)return;try{const Cls=window.AudioContext||window.webkitAudioContext;if(!Cls)return;audioContext=audioContext||new Cls();if(audioContext.state==='suspended')audioContext.resume();const now=audioContext.currentTime;const notes=win?[523,659,784,1047]:[620,830];notes.forEach((freq,i)=>{const osc=audioContext.createOscillator(),gain=audioContext.createGain(),at=now+i*(win?.12:.09);osc.type='sine';osc.frequency.setValueAtTime(freq,at);gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(.09,at+.015);gain.gain.exponentialRampToValueAtTime(.0001,at+.17);osc.connect(gain);gain.connect(audioContext.destination);osc.start(at);osc.stop(at+.18)})}catch{}}
 function popCells(path){if(!motionOn||matchMedia('(prefers-reduced-motion: reduce)').matches)return;path.forEach(i=>{const cell=board.children[i];if(!cell)return;cell.classList.remove('pop');void cell.offsetHeight;cell.classList.add('pop');setTimeout(()=>cell.classList.remove('pop'),500)})}
 function confetti(){if(!motionOn||matchMedia('(prefers-reduced-motion: reduce)').matches)return;const layer=$('effects');layer.replaceChildren();const palette=['#ffce60','#4fd3a8','#8cbbfa','#f7a1bd','#ffe0aa'];for(let i=0;i<34;i++){const dot=document.createElement('i');dot.className='confetti';dot.style.left=(5+(i*37)%90)+'%';dot.style.background=palette[i%palette.length];dot.style.setProperty('--rotation',(200+(i*127)%550)+'deg');dot.style.setProperty('--fall-time',(1100+(i*67)%1200)+'ms');dot.style.animationDelay=((i*31)%450)+'ms';layer.append(dot)}setTimeout(()=>layer.replaceChildren(),3200)}
 function evaluate(path){if(!path || path.length<2)return false;const letters=asWord(path),reverse=letters.split('').reverse().join('');const word=puzzle.words.find(w=>!found.has(w)&&(w===letters||w===reverse));if(!word){$('gameStatus').textContent='Continue procurando! Você consegue.';return false}found.set(word,path);playTone();popCells(path);save('found:'+key(),[...found]);pending=null;refreshProgress();$('gameStatus').textContent='✓ '+word+' encontrada!';if(found.size===puzzle.words.length)win();return true}
 function elementIndex(ev){const el=document.elementFromPoint(ev.clientX,ev.clientY)?.closest('.cell');if(!el || !document.getElementById('board').contains(el))return null;return Number(el.dataset.i)}
 const board=$('board');board.addEventListener('pointerdown',ev=>{if(modalOpen||ev.button!==0 || !puzzle)return;const i=elementIndex(ev);if(i===null)return;ev.preventDefault();startClock();active={start:i,end:i,moved:false,id:ev.pointerId};try{board.setPointerCapture(ev.pointerId)}catch{}refreshBoard([i])});
 board.addEventListener('pointermove',ev=>{if(!active || ev.pointerId!==active.id)return;ev.preventDefault();const i=elementIndex(ev);if(i===null)return;const selected=line(active.start,i);if(!selected.length)return;active.end=i;if(i!==active.start)active.moved=true;refreshBoard(selected)});
 board.addEventListener('pointerup',ev=>{if(!active||ev.pointerId!==active.id)return;ev.preventDefault();const d=active;active=null;const end=elementIndex(ev)??d.end;if(d.moved || end!==d.start){const path=line(d.start,d.end);pending=null;if(path.length)evaluate(path);refreshBoard();return}if(pending===null){pending=d.start;refreshBoard([pending]);$('gameStatus').textContent='Agora toque na última letra da palavra.';return}const path=line(pending,d.start);pending=null;if(path.length)evaluate(path);refreshBoard()});
 board.addEventListener('pointercancel',()=>{active=null;refreshBoard(pending===null?[]:[pending])});
 board.addEventListener('dragstart',ev=>ev.preventDefault());
 function win(){playTone(true);confetti();pauseClock();save('done:'+key(),true);updateTop();const record=load('best:'+key(),null);if(record===null||elapsed<record)save('best:'+key(),elapsed);$('restartBtn').disabled=true;$('hintBtn').disabled=true;$('modalText').textContent=`Você encontrou ${puzzle.words.length} palavras em ${formatTime(elapsed)}. Continue sua jornada!`;$('nextBtn').textContent=level===category.levels?'Ver categorias →':'Próxima fase →';$('winModal').hidden=false;modalOpen=true}
 $('hintBtn').addEventListener('click',()=>{if(hints<=0||!puzzle||found.size===puzzle.words.length)return;startClock();const next=puzzle.words.find(w=>!found.has(w));if(!next)return;hints--;$('hintCount').textContent='('+hints+')';$('hintBtn').disabled=hints===0;if(hintTimer)clearTimeout(hintTimer);document.querySelectorAll('.cell.hint').forEach(c=>c.classList.remove('hint'));const idx=puzzle.placed[next][0];board.children[idx]?.classList.add('hint');$('gameStatus').textContent='Observe a letra destacada para encontrar '+next+'.';hintTimer=setTimeout(()=>board.children[idx]?.classList.remove('hint'),2000)});
 $('restartBtn').addEventListener('click',()=>{if(!puzzle||isComplete(category,level))return;pauseClock();found.clear();save('found:'+key(),[]);save('time:'+key(),0);elapsed=0;$('clock').textContent='00:00';pending=null;hints=3;$('hintCount').textContent='(3)';$('hintBtn').disabled=false;refreshProgress();$('gameStatus').textContent='Fase reiniciada. Boa diversão!'});
 $('settingsBtn').addEventListener('click',()=>{settingsReturn=currentScreen;$('soundToggle').checked=soundOn;$('motionToggle').checked=motionOn;showScreen('settings')});
 $('settingsBack').addEventListener('click',()=>{if(settingsReturn.startsWith('cross')){window.CPMCrossword?.resume(settingsReturn);return}if(settingsReturn==='game')showScreen('game');else if(settingsReturn==='levels')showLevels();else if(settingsReturn==='shop')showScreen('shop');else showHome()});
 $('soundToggle').addEventListener('change',ev=>{soundOn=ev.target.checked;save('pref:sound',soundOn);if(soundOn)playTone()});
 $('motionToggle').addEventListener('change',ev=>{motionOn=ev.target.checked;save('pref:motion',motionOn)});
 $('startBtn').addEventListener('click',()=>{document.querySelector('#wordSearchThemes')?.scrollIntoView({behavior:'smooth',block:'start'})});
 $('changeCategory').addEventListener('click',showHome);
 $('backBtn').addEventListener('click',()=>currentScreen.startsWith('cross')?window.CPMCrossword?.back():currentScreen==='game'?showLevels():currentScreen==='shop'?showHome():currentScreen==='settings'?(settingsReturn.startsWith('cross')?window.CPMCrossword?.resume(settingsReturn):settingsReturn==='game'?showScreen('game'):settingsReturn==='levels'?showLevels():settingsReturn==='shop'?showScreen('shop'):showHome()):showHome());
 $('nextBtn').addEventListener('click',()=>level===category.levels?showHome():openLevel(level+1));
 $('levelsBtn').addEventListener('click',()=>showLevels());
 $('shareResult').addEventListener('click',()=>window.CPMSocial.openShare({mode:'wordsearch',cat:category.id,level,seconds:Math.max(1,elapsed)}));
 $('winModal').addEventListener('click',ev=>{if(ev.target===$('winModal'))showLevels()});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseClock();else if(currentScreen==='game')startClock()});
 window.CPMOpenChallenge=(mode,catId,n)=>{if(mode==='crossword'){window.CPMCrossword?.acceptChallenge?.(catId,n);return}const c=CATEGORIES.find(x=>x.id===catId);if(!c)return;category=c;if(n>c.levels)return;if(!freeLevel(c.id,n)&&!window.CPMShop.isPremium()){window.CPMShop.open();return}if(isComplete(c,n)){showLevels(c);alert('Você já concluiu esta fase. Escolha outra para continuar.');return}if(n>unlockedLevel(c)){showLevels(c);alert('Complete as fases anteriores antes de aceitar este desafio.');return}openLevel(n)};
 window.CPMOpenShop=()=>showScreen('shop');window.CPMShowHome=showHome;window.CPMShowScreen=showScreen;window.addEventListener('cpm-shop-change',()=>{if(currentScreen.startsWith('cross'))window.CPMCrossword?.onPremiumChange?.();else if(currentScreen==='levels')showLevels(category);else if(currentScreen==='home'){updateTop();renderCategories()}});
 $('soundToggle').checked=soundOn;$('motionToggle').checked=motionOn;
 if('serviceWorker' in navigator && (location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1'))navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
 showHome();
})();
