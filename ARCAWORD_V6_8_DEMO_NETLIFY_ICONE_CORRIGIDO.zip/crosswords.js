/* Palavras Cruzadas — segundo jogo do ARCAWORD. Sem frameworks. */
(() => {
 'use strict';
 const $=id=>document.getElementById(id);
 const KEY='cpm-cross-v1:';
 const TOTAL=150;
 const MAX_LEVEL=10;
 const freeTheme=id=>window.CPM_FREE_THEME_IDS.includes(id);
 const freeLevel=(id,n)=>freeTheme(id)&&n>=1&&n<=window.CPM_FREE_LEVELS;
 let cat=CATEGORIES[0],level=1,puzzle=null,cells={},selected=-1,cursor=0,hints=3,elapsed=0,clock=null,started=0,openSerial=0,finished=false;
 let activeScreen='home',lastClicked=null;
 const key=(c=cat,n=level)=>`${c.id}-${n}`;
 function get(k,fall=null){try{const v=localStorage.getItem(KEY+k);return v===null?fall:JSON.parse(v)}catch{return fall}}
 function set(k,val){try{localStorage.setItem(KEY+k,JSON.stringify(val))}catch{}}
 function done(c,n){return get('done:'+key(c,n),false)===true}
 function finishedCount(c){let n=0;for(let i=1;i<=MAX_LEVEL;i++)if(done(c,i))n++;return n}
 function unlocked(c){let n=1;while(n<MAX_LEVEL&&done(c,n))n++;return n}
 function numSolved(){return CATEGORIES.reduce((s,c)=>s+finishedCount(c),0)}
 function timerText(s){return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
 function stopClock(){if(clock){clearInterval(clock);clock=null;elapsed=Math.floor((Date.now()-started)/1000);set('time:'+key(),elapsed)}}
 function runClock(){if(clock||finished||!puzzle||activeScreen!=='crossGame')return;started=Date.now()-elapsed*1000;clock=setInterval(()=>{elapsed=Math.floor((Date.now()-started)/1000);$('crossClock').textContent=timerText(elapsed);if(elapsed%5===0)set('time:'+key(),elapsed)},700)}
 function changeScreen(to){window.CPMShowScreen(to)}
 function onScreenChange(to){stopClock();activeScreen=to;if(to==='home')$('crossTotalDone').textContent=String(numSolved());if(to==='crossGame')runClock()}
 function resume(to){changeScreen(to)}
 function openCategories(){stopClock();$('crossCategoryGrid').replaceChildren();for(const c of CATEGORIES.filter(x=>window.CPMShop.isPremium()||freeTheme(x.id))){
  const b=document.createElement('button');b.type='button';b.className='category';
  const locked=!freeTheme(c.id)&&!window.CPMShop.isPremium();b.classList.toggle('category-paylocked',locked);b.innerHTML=`<span class="category-emoji">${c.emoji}</span><strong>${c.title}${locked?' 👑':''}</strong><small>${freeTheme(c.id)?(window.CPMShop.isPremium()?'Acesso total • ':'2 fases grátis • '):'Premium liberado • '}${finishedCount(c)}/${MAX_LEVEL} fases concluídas</small><span class="category-arrow">›</span>`;
  b.addEventListener('click',()=>locked?window.CPMShop.open():openLevels(c));$('crossCategoryGrid').append(b);
 }
 changeScreen('crossCategories')}
 function openLevels(c=cat){if(!freeTheme(c.id)&&!window.CPMShop.isPremium()){window.CPMShop.open();return}cat=c;$('crossCategoryEmoji').textContent=c.emoji;$('crossCategoryTitle').textContent=c.title;$('crossCategorySubtitle').textContent=`${finishedCount(c)} de 10 fases concluídas`;
  const box=$('crossLevelGrid');box.replaceChildren();const available=unlocked(c);
  for(let n=1;n<=MAX_LEVEL;n++){
   const paid=!freeLevel(c.id,n)&&!window.CPMShop.isPremium(),completed=done(c,n),locked=n>available&&!completed&&!paid;
   const b=document.createElement('button');b.type='button';b.className='level'+(completed?' completed':paid?' premium-locked':locked?' locked':'');b.disabled=locked||completed;
   b.setAttribute('aria-label',`Cruzadas fase ${n}${completed?' concluída':paid?' Premium':locked?' bloqueada':''}`);
   b.innerHTML=completed?`✓<span>Fase ${n}</span>`:paid?`👑<span>Fase ${n}</span>`:locked?`🔒<span>Fase ${n}</span>`:`${n}<span>JOGAR</span>`;
   b.addEventListener('click',()=>paid?window.CPMShop.open():openLevel(n));box.append(b);
  }
  changeScreen('crossLevels')}
 async function openLevel(n){
  if(done(cat,n)){openLevels();return}
  if(!freeLevel(cat.id,n)&&!window.CPMShop.isPremium()){window.CPMShop.open();return}
  if(n>unlocked(cat)&&!done(cat,n)){openLevels();return}
  const serial=++openSerial,reqCat=cat;stopClock();let data;
  if(freeLevel(cat.id,n))data=window.CPM_FREE_CROSSWORDS?.[key(cat,n)];
  else{
   try{data=await window.CPMShop.getCrossword(cat.id,n)}catch(e){if(serial!==openSerial)return;alert('Não foi possível carregar esta cruzada Premium. Confira sua conexão e acesso.\n'+e.message);window.CPMShop.open();return}
  }
  if(serial!==openSerial||reqCat!==cat)return;
  if(!data){alert('Esta fase não está disponível.');return}
  level=n;puzzle=data;cells=get('cells:'+key(),{})||{};
  const valid=new Set(data.entries.flatMap(e=>paths(e)));
  cells=Object.fromEntries(Object.entries(cells).filter(([k,v])=>valid.has(k)&&/^[A-Z]$/.test(v)));
  finished=done(cat,level);hints=3;elapsed=get('time:'+key(),0)||0;selected=0;cursor=0;
  set('last',{cat:cat.id,level});$('crossClock').textContent=timerText(elapsed);
  $('crossGameCategory').textContent='✏️ '+cat.title.toUpperCase();$('crossGameLevel').textContent='Fase '+level;$('crossDifficulty').textContent=puzzle.levelName;
  $('crossHintCount').textContent='(3)';$('crossHintBtn').disabled=finished;$('crossRestartBtn').disabled=finished;
  $('crossWinModal').hidden=true;
  renderBoard();renderClues();selectWord(0,false);updateState();
  $('crossStatus').textContent=finished?'Fase concluída e salva. Escolha uma nova fase.':'Toque na dica ou em uma casa para digitar.';
  changeScreen('crossGame');
 }
 function paths(e){return Array.from({length:e.word.length},(_,i)=>`${e.row+(e.dir==='V'?i:0)},${e.col+(e.dir==='H'?i:0)}`)}
 function entrySolved(e){return paths(e).map(k=>cells[k]||'').join('')===e.word}
 function allDone(){return puzzle.entries.every(entrySolved)}
 function renderBoard(){const root=$('crossBoard');root.replaceChildren();root.style.setProperty('--cross-cols',puzzle.width);
  const numbers=new Map(puzzle.entries.map(e=>[`${e.row},${e.col}`,e.number]));
  for(let r=0;r<puzzle.height;r++)for(let c=0;c<puzzle.width;c++){
   const k=`${r},${c}`,exists=!!puzzle.grid[r][c],b=document.createElement(exists?'button':'div');
   b.className='cross-square'+(exists?'':' black');
   if(exists){b.type='button';b.dataset.cell=k;b.setAttribute('role','gridcell');b.setAttribute('aria-label',`Linha ${r+1}, coluna ${c+1}`);
    const num=numbers.get(k);if(num){const label=document.createElement('span');label.className='cross-number';label.textContent=num;b.append(label)}
    const letter=document.createElement('span');letter.className='cross-letter';letter.textContent=cells[k]||'';b.append(letter);
    b.addEventListener('click',()=>chooseCell(k));
   }else b.setAttribute('aria-hidden','true');
   root.append(b);
  }
 }
 function renderClues(){for(const [side,id] of [['H','crossAcross'],['V','crossDown']]){
  const parent=$(id);parent.replaceChildren();for(let i=0;i<puzzle.entries.length;i++){
   const e=puzzle.entries[i];if(e.dir!==side)continue;
   const btn=document.createElement('button');btn.className='cross-clue';btn.type='button';btn.dataset.entry=String(i);
   btn.innerHTML=`<strong>${e.number}.</strong> ${e.clue} <small>(${e.word.length} letras)</small>`;
   btn.addEventListener('click',()=>selectWord(i,true));parent.append(btn);
  }
 }}
 function chooseCell(k){
  const options=puzzle.entries.map((e,i)=>({i,index:paths(e).indexOf(k)})).filter(x=>x.index>=0);
  if(!options.length)return;
  let next=options[0];
  const current=options.find(x=>x.i===selected);
  if(current&&options.length>1&&k===lastClicked)next=options.find(x=>x.i!==selected)||current;
  else if(current)next=current;
  selected=next.i;cursor=next.index;lastClicked=k;
  refreshSelection();focusType();
 }
 function firstEditable(e){return 0}
 function selectWord(i,focus=true){lastClicked=null;selected=i;cursor=firstEditable(puzzle.entries[i]);refreshSelection();if(focus)focusType()}
 function refreshSelection(){if(!puzzle||selected<0)return;
  const e=puzzle.entries[selected],currentPath=paths(e),activeKey=currentPath[cursor];
  $('crossActiveClue').textContent=`${e.number}${e.dir==='H'?' horizontal':' vertical'}: ${e.clue} (${e.word.length} letras)`;
  for(const b of $('crossBoard').querySelectorAll('button[data-cell]')){
   const k=b.dataset.cell;
   b.classList.toggle('active-word',currentPath.includes(k));b.classList.toggle('cursor',k===activeKey);
   b.querySelector('.cross-letter').textContent=cells[k]||'';
   b.classList.toggle('solved',puzzle.entries.some(x=>entrySolved(x)&&paths(x).includes(k)));
  }
  for(const b of document.querySelectorAll('.cross-clue')){
   const i=Number(b.dataset.entry);b.classList.toggle('selected',i===selected);b.classList.toggle('complete',entrySolved(puzzle.entries[i]));
  }
 }
 function focusType(){const input=$('crossType');input.value='';try{input.focus({preventScroll:true})}catch{input.focus()}}
 function updateState(){const doneCount=puzzle.entries.filter(entrySolved).length;
  $('crossFoundCounter').textContent=doneCount+'/'+puzzle.entries.length;$('crossProgressFill').style.width=(100*doneCount/puzzle.entries.length)+'%';refreshSelection();
  if(doneCount===puzzle.entries.length&&!finished){finished=true;stopClock();set('time:'+key(),elapsed);set('done:'+key(),true);$('crossRestartBtn').disabled=true;
   $('crossHintBtn').disabled=true;$('crossStatus').textContent='Parabéns! Você encontrou todas as respostas!';
   $('crossWinText').textContent=`Você completou a fase ${level} de ${cat.title} em ${timerText(elapsed)}.`;
   $('crossNextBtn').textContent=level===MAX_LEVEL?'Escolher outro tema →':'Próxima fase →';
   $('crossWinModal').hidden=false;
   try{const x=new (window.AudioContext||window.webkitAudioContext)();const o=x.createOscillator(),g=x.createGain();o.frequency.value=800;g.gain.value=.06;o.connect(g);g.connect(x.destination);o.start();o.stop(x.currentTime+.2);setTimeout(()=>x.close(),500)}catch{}
  }
 }
 function writeLetters(raw){if(!puzzle||finished||selected<0)return;
  const letters=raw.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z]/g,'');
  if(!letters)return;
  const p=paths(puzzle.entries[selected]);
  for(const v of letters){if(cursor>=p.length)break;cells[p[cursor]]=v;cursor=Math.min(p.length,cursor+1)}
  if(cursor>=p.length)cursor=p.length-1;
  set('cells:'+key(),cells);updateState();
 }
 function removeLetter(){if(!puzzle||finished)return;
  const p=paths(puzzle.entries[selected]);
  const at=p[cursor];if(!cells[at]&&cursor>0)cursor--;delete cells[p[cursor]];
  set('cells:'+key(),cells);updateState();
 }
 function hint(){if(!puzzle||finished||hints<=0)return;
  const current=puzzle.entries[selected];const keys=paths(current);
  const target=keys.findIndex((k,i)=>cells[k]!==current.word[i]);
  if(target<0){$('crossStatus').textContent='Esta resposta já está correta. Escolha outra dica.';return}
  cells[keys[target]]=current.word[target];cursor=target;
  hints--;$('crossHintCount').textContent=`(${hints})`;if(!hints)$('crossHintBtn').disabled=true;
  set('cells:'+key(),cells);$('crossStatus').textContent='💡 Uma letra foi revelada.';updateState();
 }
 function restart(){if(!puzzle||done(cat,level)||!confirm('Apagar as letras preenchidas desta fase e começar novamente?'))return;
  cells={};finished=false;hints=3;elapsed=0;set('cells:'+key(),cells);set('done:'+key(),false);set('time:'+key(),0);
  $('crossWinModal').hidden=true;$('crossHintCount').textContent='(3)';$('crossHintBtn').disabled=false;$('crossClock').textContent='00:00';
  renderBoard();renderClues();selectWord(0,false);updateState();runClock();
 }
 function back(){if(activeScreen==='crossGame'){++openSerial;stopClock();$('crossWinModal').hidden=true;openLevels()}
  else if(activeScreen==='crossLevels')openCategories();else window.CPMShowHome()}
 function onPremiumChange(){if(activeScreen==='crossLevels')openLevels(cat);else if(activeScreen==='crossCategories')openCategories()}
 $('crosswordMode').addEventListener('click',openCategories);
 $('wordSearchMode').addEventListener('click',()=>document.getElementById('wordSearchThemes').scrollIntoView({behavior:'smooth',block:'start'}));
 $('crossBackHome').addEventListener('click',()=>window.CPMShowHome());
 $('crossBackCategories').addEventListener('click',openCategories);
 $('crossHintBtn').addEventListener('click',hint);
 $('crossRestartBtn').addEventListener('click',restart);
 $('crossType').addEventListener('input',e=>{const input=e.currentTarget;const txt=input.value;input.value='';writeLetters(txt)});
 $('crossType').addEventListener('keydown',e=>{
  if(e.key==='Backspace'){e.preventDefault();removeLetter()}
  else if(e.key==='ArrowLeft'){cursor=Math.max(0,cursor-1);refreshSelection();e.preventDefault()}
  else if(e.key==='ArrowRight'){cursor=Math.min(paths(puzzle.entries[selected]).length-1,cursor+1);refreshSelection();e.preventDefault()}
  else if(e.key==='Enter'){e.preventDefault();$('crossType').blur()}
 });
 $('crossNextBtn').addEventListener('click',()=>{ $('crossWinModal').hidden=true;level===MAX_LEVEL?openCategories():openLevel(level+1)});
 $('crossAllBtn').addEventListener('click',()=>{$('crossWinModal').hidden=true;openLevels()});
 $('crossShareResult').addEventListener('click',()=>window.CPMSocial.openShare({mode:'crossword',cat:cat.id,level,seconds:Math.max(1,elapsed)}));
 $('crossWinModal').addEventListener('click',e=>{if(e.target===$('crossWinModal')){$('crossWinModal').hidden=true;openLevels()}});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)stopClock();else if(activeScreen==='crossGame')runClock()});
 window.CPMCrossword={openCategories,openLevels,back,resume,onScreenChange,onPremiumChange,acceptChallenge:(catId,n)=>{const c=CATEGORIES.find(x=>x.id===catId);if(!c||n>MAX_LEVEL)return;cat=c;if(!freeLevel(c.id,n)&&!window.CPMShop.isPremium()){window.CPMShop.open();return}if(done(c,n)){openLevels(c);alert('Você já concluiu esta fase. Escolha outra para continuar.');return}if(n>unlocked(c)){openLevels(c);alert('Complete as fases anteriores para aceitar o desafio.');return}openLevel(n)}};
})();
