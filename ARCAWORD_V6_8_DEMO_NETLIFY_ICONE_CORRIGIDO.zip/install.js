/* ARCAWORD 6.8 — Instalação opcional (iOS Safari e Android compatível).
   Nenhum navegador permite instalar silenciosamente: confirmação do usuário é sempre necessária. */
(()=>{'use strict';
 const $=(id)=>document.getElementById(id);
 const modal=$('installModal'),action=$('installAction'),later=$('installLater'),steps=$('installInstructions');
 if(!modal||!action||!later||!steps)return;
 const entry=$('installEntry'),settingsButton=$('installSettingsBtn'),settingsText=$('installSettingsText');
 const DISMISS_KEY='arcaword:install:hide-until';
 const HIDE_DAYS=14;
 const installed=()=>Boolean(window.matchMedia?.('(display-mode: standalone)')?.matches||window.matchMedia?.('(display-mode: fullscreen)')?.matches||navigator.standalone===true);
 const ua=()=>navigator.userAgent||'';
 const isIOS=()=>/iPad|iPhone|iPod/i.test(ua())||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
 const isAndroid=()=>/Android/i.test(ua());
 const isMobile=()=>isIOS()||isAndroid();
 const inAppBrowser=()=>/Instagram|FBAN|FBAV|FB_IAB|WhatsApp|Line\//i.test(ua());
 let deferredPrompt=null,lastFocused=null,wasOpened=false;
 const snoozed=()=>{try{return Number(localStorage.getItem(DISMISS_KEY)||0)>Date.now()}catch{return false}};
 const snooze=()=>{try{localStorage.setItem(DISMISS_KEY,String(Date.now()+HIDE_DAYS*864e5))}catch{}};
 const setVisible=()=>{
   const show=isMobile()&&!installed();
   if(entry)entry.hidden=!show;
   if(settingsButton)settingsButton.hidden=installed();
   if(settingsText)settingsText.textContent=installed()?'Este aparelho já está usando o ARCAWORD como aplicativo.':'Instale grátis para abrir o ARCAWORD pelo ícone personalizado na tela inicial.';
 };
 const setSteps=(title,items,note='')=>{
   steps.replaceChildren();
   const strong=document.createElement('strong');strong.textContent=title;steps.appendChild(strong);
   const list=document.createElement('ol');
   for(const item of items){const li=document.createElement('li');li.textContent=item;list.appendChild(li)}
   steps.appendChild(list);
   if(note){const p=document.createElement('p');p.textContent=note;steps.appendChild(p)}
   steps.hidden=false;
 };
 const updateAction=()=>{
   if(isIOS()) action.textContent='📲 Ver como instalar no iPhone';
   else if(deferredPrompt)action.textContent='📲 Instalar ARCAWORD';
   else if(isAndroid())action.textContent='📲 Ver como instalar no Android';
   else action.textContent='📲 Como instalar';
 };
 const close=(remember=false)=>{if(remember)snooze();modal.hidden=true;steps.hidden=true;wasOpened=false;lastFocused?.focus?.();lastFocused=null};
 function open(){
   if(installed())return;
   lastFocused=document.activeElement;
   steps.hidden=true;action.dataset.mode='';modal.hidden=false;wasOpened=true;updateAction();action.focus();
 }
 function manualInstructions(){
   if(isIOS()){
     if(inAppBrowser()){
       setSteps('Abra o link no Safari para instalar',[
         'No WhatsApp ou Instagram, abra o menu da página e escolha Abrir no Safari (se estiver disponível).',
         'No Safari, toque em Compartilhar (quadrado com seta para cima).',
         'Escolha Adicionar à Tela de Início.',
         'Ative Abrir como App, quando aparecer, e toque em Adicionar.'
       ],'Se não aparecer Abrir no Safari, copie o link do jogo e cole no Safari.');
     }else{
       setSteps('Instalar no iPhone',[
         'No Safari, toque em Compartilhar (quadrado com seta para cima).',
         'Procure a opção Adicionar à Tela de Início.',
         'Ative Abrir como App, se a opção aparecer.',
         'Confira se aparece o símbolo ARCAWORD na prévia do ícone antes de tocar em Adicionar.'
       ],'Se aparecer uma miniatura da página em vez do ícone ARCAWORD, cancele, atualize a página e tente novamente. Ícones antigos já instalados não mudam automaticamente.');
     }
   }else if(isAndroid()){
     setSteps('Instalar no Android',[
       'Abra o ARCAWORD no Chrome.',
       'Toque no menu do navegador (⋮).',
       'Escolha Instalar app ou Adicionar à tela inicial.',
       'Confirme a instalação quando o Android solicitar.'
     ],'O botão de instalação pode variar conforme o navegador.');
   }else{
     setSteps('Instalar no computador',[
       'Abra o site em um navegador compatível.',
       'Procure Instalar aplicativo no menu ou na barra de endereço.',
       'Confirme a instalação.'
     ]);
   }
   action.textContent='✓ Entendi';action.dataset.mode='done';snooze();
 }
 action.addEventListener('click',async()=>{
   if(action.dataset.mode==='done'){close(false);return}
   if(!isIOS() && deferredPrompt){
     const event=deferredPrompt;deferredPrompt=null;
     try{
       // prompt() requer gesto do usuário e pode existir somente uma vez por evento.
       await event.prompt();
       const choice=await event.userChoice;
       if(choice?.outcome==='accepted'){snooze();close(false);setVisible();return}
       snooze();close(false);setVisible();return;
     }catch{manualInstructions();return}
   }
   manualInstructions();
 });
 later.addEventListener('click',()=>close(true));
 $('installClose')?.addEventListener('click',()=>close(true));
 modal.addEventListener('click',(ev)=>{if(ev.target===modal)close(true)});
 document.addEventListener('keydown',(ev)=>{
   if(modal.hidden)return;
   if(ev.key==='Escape'){ev.preventDefault();close(true);return}
   if(ev.key==='Tab'){
     const buttons=[...modal.querySelectorAll('button:not([hidden])')].filter(x=>!x.disabled);
     const first=buttons[0],last=buttons[buttons.length-1];
     if(ev.shiftKey&&document.activeElement===first){ev.preventDefault();last.focus()}
     if(!ev.shiftKey&&document.activeElement===last){ev.preventDefault();first.focus()}
   }
 });
 entry?.addEventListener('click',open);
 settingsButton?.addEventListener('click',open);
 window.addEventListener('beforeinstallprompt',event=>{
   event.preventDefault();deferredPrompt=event;
   if(wasOpened){action.dataset.mode='';updateAction()}
   setVisible();
 });
 window.addEventListener('appinstalled',()=>{deferredPrompt=null;close(false);setVisible()});
 if(window.matchMedia){
   try{window.matchMedia('(display-mode: standalone)').addEventListener?.('change',setVisible)}catch{}
 }
 setVisible();
 // A primeira visita oferece instalação só na tela inicial e nunca interrompe partidas ou outras janelas.
 if(isMobile()&&!installed()&&!snoozed()){
   window.setTimeout(()=>{
     const home=$('homeScreen');
     if(document.visibilityState!=='hidden'&&home&&!home.hidden&&
         !installed()&&!snoozed()&&!document.querySelector('.modal:not([hidden])'))open();
   },2800);
 }
 window.ARCAWORDInstall={open,installed};
})();
