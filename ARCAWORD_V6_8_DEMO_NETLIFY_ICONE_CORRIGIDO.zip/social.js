/* ARCAWORD 6.2 — compartilhamento e convites, sem banco de dados. */
(() => {
 'use strict';
 const $=id=>document.getElementById(id);
 const modes=['wordsearch','crossword'];
 const valid=s=>s && modes.includes(s.mode) && CATEGORIES.some(c=>c.id===s.cat && Number.isInteger(Number(s.level)) && Number(s.level)>=1 && Number(s.level)<=(s.mode==='crossword'?10:c.levels));
 const norm=s=>({mode:s.mode,cat:s.cat,level:Number(s.level)});
 const label=s=>`${s.mode==='crossword'?'Palavras cruzadas':'Caça-palavras'} • ${CATEGORIES.find(c=>c.id===s.cat)?.title||'Tema'} • Fase ${s.level}`;
 const formatTime=n=>`${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;
 let shareStage=null,incomingStage=null;
 function makeUrl(s){
  const url=new URL(location.pathname,location.origin);
  if(s&&valid(s)){
   url.searchParams.set('desafio','1');url.searchParams.set('modo',s.mode);
   url.searchParams.set('tema',s.cat);url.searchParams.set('fase',String(s.level));
  }
  return url.toString();
 }
 function buildShare(){
  if(!shareStage)return {title:'ARCAWORD',text:'🎮 Conheça o ARCAWORD! Caça-palavras e palavras cruzadas, com 2 fases grátis por jogo em cada um dos 4 temas. Venha jogar:',url:makeUrl(null)};
  const t=Number(shareStage.seconds);
  const time=Number.isFinite(t)&&t>0?` Eu completei em ${formatTime(t)}.`:'';
  return {title:'ARCAWORD',text:`🧩 Te desafio a resolver esta fase do ARCAWORD: ${label(shareStage)}.${time} Sua vez!`,url:makeUrl(shareStage)};
 }
 function feedback(t){$('shareFeedback').textContent=t}
 function openShare(s=null){shareStage=valid(s)?{...norm(s),seconds:s.seconds}:null;
  $('shareDescription').textContent=shareStage?`Convide alguém para jogar ${label(shareStage)}.`:'Convide seus amigos para conhecer os dois jogos!';
  feedback('');$('shareModal').hidden=false;$('shareClose').focus();
 }
 function closeShare(){$('shareModal').hidden=true}
 async function copyText(t){
  if(navigator.clipboard?.writeText){try{await navigator.clipboard.writeText(t);return true}catch{}}
  const el=document.createElement('textarea');el.value=t;el.style.position='fixed';el.style.opacity='0';document.body.appendChild(el);el.select();let result=false;
  try{result=document.execCommand('copy')}catch{}el.remove();return result;
 }
 async function nativeShare(){const d=buildShare();if(navigator.share){try{await navigator.share(d);feedback('Selecione o aplicativo para compartilhar.');return}catch(e){if(e.name==='AbortError')return}}
  feedback(await copyText(d.text+' '+d.url)?'Convite copiado! Cole no aplicativo de sua preferência.':'Copie o link do jogo na barra de endereços.');
 }
 function whatsapp(){const d=buildShare(),u='https://wa.me/?text='+encodeURIComponent(d.text+' '+d.url);
  const a=document.createElement('a');a.href=u;a.target='_blank';a.rel='noopener noreferrer';document.body.appendChild(a);a.click();a.remove();
  feedback('Selecione a pessoa ou o grupo no WhatsApp para enviar.');
 }
 async function instagram(){const d=buildShare();
  // O navegador não consegue publicar Stories diretamente ou adicionar adesivos de link automaticamente.
  const copied=await copyText(d.url);
  if(navigator.share){try{await navigator.share(d);feedback('Se o Instagram aparecer, selecione-o. Para Stories, adicione um adesivo de link.');return}catch(e){if(e.name==='AbortError'){feedback(copied?'Link copiado!':'Compartilhamento cancelado.');return}}}
  feedback(copied?'Link copiado! Cole numa conversa do Instagram ou use o adesivo de link nos Stories.':'Copie o endereço do jogo para compartilhar no Instagram.');
 }
 function receiveChallenge(){const q=new URLSearchParams(location.search);if(q.get('desafio')!=='1')return;
  const stage={mode:q.get('modo'),cat:q.get('tema'),level:Number(q.get('fase'))};if(!valid(stage))return;
  incomingStage=norm(stage);$('challengeInvitationText').textContent=`${label(incomingStage)}. Aceite e tente resolver!`;
  $('challengeInvitation').hidden=false;
 }
 function acceptChallenge(){if(!incomingStage)return;const s=incomingStage;incomingStage=null;$('challengeInvitation').hidden=true;
  const u=new URL(location.href);['desafio','modo','tema','fase'].forEach(k=>u.searchParams.delete(k));history.replaceState({},'',u.pathname+u.search+u.hash);
  window.CPMOpenChallenge?.(s.mode,s.cat,s.level);
 }
 function init(){
  $('shareHome').addEventListener('click',()=>openShare());
  $('shareClose').addEventListener('click',closeShare);
  $('shareModal').addEventListener('click',e=>{if(e.target===$('shareModal'))closeShare()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('shareModal').hidden)closeShare()});
  $('shareWhatsapp').addEventListener('click',whatsapp);
  $('shareInstagram').addEventListener('click',instagram);
  $('shareNative').addEventListener('click',nativeShare);
  $('shareCopy').addEventListener('click',async()=>feedback(await copyText(buildShare().url)?'Link copiado!':'Não foi possível copiar automaticamente.'));
  $('acceptChallenge').addEventListener('click',acceptChallenge);
  receiveChallenge();
 }
 window.CPMSocial={openShare,makeUrl};
 window.addEventListener('load',init);
})();
